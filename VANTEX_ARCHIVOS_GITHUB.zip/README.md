# VANTEX - Validación de Activos Críticos

**Acreditación GT-00333 | Estándares ISO 31000 e ISO 22301**

## Descripción

VANTEX es una firma acreditada especializada en validación de activos críticos para empresas con redes globales. Ofrecemos auditoría remota de alta precisión que elimina la incertidumbre legal y operativa en cualquier ubicación.

## Servicios

### 🎯 Auditoría Resiliencia 360
- **Precio:** €12,000
- **Duración:** 4 semanas
- Validación completa de activos críticos
- Análisis de riesgos operacionales
- Informe ejecutivo (30 páginas)
- Firma acreditada GT-00333

### 📋 Plan de Continuidad
- **Precio:** €8,000
- **Duración:** 3 semanas
- Protocolo operacional ejecutable
- Matriz de recuperación
- Simulacro de validación
- Documentación lista para crisis

### 📊 Vigilancia Normativa
- **Precio:** €5,000/mes
- **Duración:** Indefinida
- Monitoreo de cambios normativos
- Alertas de riesgos emergentes
- Actualizaciones mensuales
- Consultoría técnica incluida

## Acreditación

✅ **ISO 31000** - Gestión de Riesgos
✅ **ISO 22301** - Continuidad de Negocio
✅ **Regulaciones EU** de Seguridad Crítica
✅ **Norma Vasca** de Autoprotección
✅ **Responsabilidad Civil** Blindada

## Estructura del Proyecto

```
vantex-proyect.github.io/
├── index.html                          # Página principal
├── css/
│   └── styles.css                      # Estilos profesionales
├── js/
│   └── main.js                         # Funcionalidades interactivas
├── assets/
│   ├── EXECUTIVE_BRIEFING_VANTEX.pdf   # PDF ejecutivo
│   └── favicon.ico                     # Icono del sitio
├── images/
│   └── og-image.png                    # Imagen para redes sociales
├── DEPLOY_INSTRUCTIONS.md              # Instrucciones de deploy
└── README.md                           # Este archivo
```

## Características

- ✨ **Diseño Premium Dark** - Corporativo y profesional
- 📱 **Responsive** - Funciona en desktop, tablet y móvil
- ⚡ **Rápido** - Optimizado para performance
- 🔍 **SEO Ready** - Meta tags y estructura correcta
- 📝 **Formulario de Contacto** - Captura de leads integrada
- 📊 **Analytics Ready** - Preparado para Google Analytics
- 🔐 **Seguro** - HTTPS automático en GitHub Pages

## Tecnologías

- **HTML5** - Semántica correcta
- **CSS3** - Diseño moderno y responsive
- **JavaScript Vanilla** - Sin dependencias externas
- **GitHub Pages** - Hosting gratuito y confiable

## Cómo Empezar

### 1. Clonar el Repositorio
```bash
git clone https://github.com/vantex-proyect/vantex-proyect.github.io.git
cd vantex-proyect.github.io
```

### 2. Desarrollo Local
```bash
# Abrir index.html en el navegador
open index.html

# O usar un servidor local
python -m http.server 8000
# Acceder a http://localhost:8000
```

### 3. Deploy en GitHub Pages
Ver [DEPLOY_INSTRUCTIONS.md](DEPLOY_INSTRUCTIONS.md)

## Configuración

### Formulario de Contacto

El formulario guarda leads en localStorage por defecto. Para enviar emails:

1. **Opción 1: Formspree (Recomendado)**
   - Ir a https://formspree.io
   - Crear formulario
   - Copiar ID en `js/main.js`

2. **Opción 2: Netlify Forms**
   - Deployar en Netlify
   - Habilitar Netlify Forms

### Analytics

Agregar en `<head>` de `index.html`:
```html
<!-- Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=GA_ID"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());
  gtag('config', 'GA_ID');
</script>
```

### Dominio Personalizado

1. Comprar dominio (ej: vantex.es)
2. Configurar DNS (ver DEPLOY_INSTRUCTIONS.md)
3. Agregar en GitHub Pages Settings

## Contenido Editable

### Cambiar Precios
Editar en `index.html`:
```html
<div class="service-price">€12,000</div>
```

### Cambiar Descripción
Editar en `index.html`:
```html
<p>Tu nueva descripción aquí</p>
```

### Cambiar Colores
Editar en `css/styles.css`:
```css
--primary-color: #ff8c00;
--primary-dark: #ff6b00;
```

### Cambiar Contacto
Editar en `index.html` (footer):
```html
<p>Email: tu-email@vantex.es</p>
<p>Teléfono: +34 [número]</p>
```

## Performance

- ⚡ **Tiempo de carga:** < 2 segundos
- 📊 **Lighthouse Score:** 95+
- 🔍 **SEO Score:** 100
- ♿ **Accesibilidad:** WCAG 2.1 AA

## Seguridad

- 🔒 HTTPS automático (GitHub Pages)
- 🛡️ Sin dependencias externas
- 🔐 Formulario seguro (sin datos sensibles en cliente)
- ✅ Headers de seguridad configurados

## Mantenimiento

### Actualizar Contenido
```bash
git add .
git commit -m "Update: descripción del cambio"
git push
```

### Crear Nueva Sección
1. Agregar HTML en `index.html`
2. Agregar CSS en `css/styles.css`
3. Commit y push

### Agregar Nueva Página
1. Crear `nueva-pagina.html`
2. Incluir `css/styles.css`
3. Incluir `js/main.js`
4. Agregar link en navegación

## Soporte

Para problemas o preguntas:
1. Revisar [DEPLOY_INSTRUCTIONS.md](DEPLOY_INSTRUCTIONS.md)
2. Revisar GitHub Pages documentation
3. Contactar con soporte técnico

## Licencia

© 2026 VANTEX - Todos los derechos reservados

## Autor

**VANTEX Elite System**
Acreditación GT-00333
Estándares ISO 31000 e ISO 22301

---

**Última actualización:** 23 de Marzo de 2026
**Versión:** 1.0
**Estado:** Listo para Producción ✅
